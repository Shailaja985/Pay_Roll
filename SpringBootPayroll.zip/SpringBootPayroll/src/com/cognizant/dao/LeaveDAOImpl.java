package com.cognizant.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Component;

import com.cognizant.entity.Employee;
import com.cognizant.exception.EmployeeException;
@Component
public class LeaveDAOImpl implements LeaveDAO {

	private static final long serialVersionUID = 1L;

	public LeaveDAOImpl() {
		super();
	}

	@SuppressWarnings("deprecation")
	public Employee getViewSalary(int empid) throws EmployeeException {

		Double salary = 0.0;

		List<Employee> employeeList = new ArrayList<Employee>();
		List<Date> leaveStartDateList = new ArrayList<Date>();
		List<Date> leaveEndDateList = new ArrayList<Date>();
		List<LocalDate> allLeaveDates = new ArrayList<LocalDate>();
		try {

			try {
				SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
				Session session = sessionFactory.openSession();

				employeeList = session.createQuery("From Employee").list();
				leaveStartDateList = session.createQuery("SELECT leaveStartDate FROM Leave1 where empId=" + empid).list();
				leaveEndDateList = session.createQuery("SELECT leaveEndDate FROM Leave1 where empId=" + empid).list();

			} catch (Exception e) {
				throw new EmployeeException(e.getMessage());
			}

			for (int i = 0; i < leaveEndDateList.size(); i++) {

				LocalDate start = leaveStartDateList.get(i).toLocalDate();
				LocalDate end = leaveEndDateList.get(i).toLocalDate();

				while (!start.isAfter(end)) {
					allLeaveDates.add(start);
					start = start.plusDays(1);
				}
			}
			int totalLeaves = 0;
			LocalDate now = LocalDate.now();
			LocalDate earlier = now.minusMonths(1);
			Month previousMonth = earlier.getMonth();
			int totalDaysInMonth = previousMonth.maxLength();
			for (Employee employee : employeeList) {

				if (empid == employee.getEmpId()) {
					salary = employee.getSalary();
					for (LocalDate date : allLeaveDates) {
						if (date.getMonthValue() == previousMonth.getValue()) {
							totalLeaves++;
						}
					}
					System.out.println(totalLeaves);
					if (totalLeaves > 2) {

						int unpaidLeaves = totalLeaves - 2;
						Double salaryForADay = salary / totalDaysInMonth;
						salary = salary - (salaryForADay * unpaidLeaves);
						employee.setSalary(salary);
					}
					return employee;
				}
			}

		} catch (HibernateException e) {
			throw new EmployeeException("No such Employee");
		}

		return null;
	}

}
