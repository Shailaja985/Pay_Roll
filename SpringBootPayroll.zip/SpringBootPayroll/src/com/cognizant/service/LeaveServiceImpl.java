package com.cognizant.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.LeaveDAO;
import com.cognizant.dao.LeaveDAOImpl;
import com.cognizant.entity.Employee;
import com.cognizant.exception.EmployeeException;
@Service
public class LeaveServiceImpl implements LeaveService {
@Autowired
	private LeaveDAO leaveDAO=null;
	
	public LeaveServiceImpl() {
		super();
		this.leaveDAO = new LeaveDAOImpl();
	}


public Employee getViewSalary(int empId) {

	Employee employee = null;
	try {
		
		LocalDate now = LocalDate.now();
		LocalDate earlier = now.minusMonths(1);
		employee = leaveDAO.getViewSalary(empId);
		
		System.out.println("Salary for employee.."+employee.getName()+" for the month of "+earlier.getMonth()+" is: "+employee.getSalary());
		

	} catch (EmployeeException e) {
		System.out.println(e.getMessage());
	}
	
	return employee;
}


}