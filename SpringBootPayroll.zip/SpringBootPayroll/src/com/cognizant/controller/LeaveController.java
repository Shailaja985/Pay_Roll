package com.cognizant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.entity.Employee;
import com.cognizant.entity.Leave1;
import com.cognizant.service.LeaveServiceImpl;

@RestController
@RequestMapping(value = "/")
public class LeaveController {
	@Autowired
	private LeaveServiceImpl leaveserviceimpl;

	@RequestMapping(value = "/leavecontroller", method = RequestMethod.POST)
	public Employee getViewSalary(int empId, @RequestBody Employee employee, @RequestBody Leave1 leave) {
		empId = 770060;
		return leaveserviceimpl.getViewSalary(empId);
	}
}
