package com.cognizant.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="leave1")
public class Leave1
{ /*implements Serializable {
	/**
	 
	private static final long serialVersionUID = -5119716330336646593L;

	public Leave1() {

	}*/

	@Id
	/*
	 * private int grantLeaveId; private Date startDate; private Date endDate;
	 * private String status; private int totalDays;
	 */
	
//	@OneToMany(targetEntity=Leave.class, mappedBy="Leave1", fetch=FetchType.EAGER)
	private int empId;
	private Date leaveStartDate;
	private Date leaveEndDate;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public Date getLeaveStartDate() {
		return leaveStartDate;
	}

	public void setLeaveStartDate(Date leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}
	
	public Date getLeaveEndDate() {
		return leaveEndDate;
	}

	public void setLeaveEndDate(Date leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}

}
