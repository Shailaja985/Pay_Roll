package com.cognizant.service;

import com.cognizant.entity.Employee;

public interface LeaveService {

Employee getViewSalary(int empId);
}